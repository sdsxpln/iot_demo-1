#include "systick.h"

static volatile uint32_t sysTickMillis = 0;
static uint32_t sysTickPerUs = 72;//ϵͳ�ں�ʱ�� ����λ��Mhz��
uint32_t idleMax=0;

void delay_x_ms(uint32_t xms)
{
	
	uint32_t x,i;
	for(i=0;i<xms;i++){
	if(idleMax!=0&&idleMax>700){
	x=idleMax;
	}else{
	x=732;//Լ����1ms
	}
	while(x--){
	}
	}
}
void initSystick(void)
{
	sysTickPerUs = SystemCoreClock / 1000000;
	SysTick_Config(SystemCoreClock / 1000);//1ms�ж�
}


static  int systick_check_underflow(void)//����24λ�ݼ��������Ƿ����0��־
{
    return SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk;
}


void SysTick_Handler(void)
{
    __disable_irq();
    systick_check_underflow();
    sysTickMillis++;
    __enable_irq();

   
}

unsigned int millis(void)
{
    return sysTickMillis;
}


unsigned int micros(void)
{
    uint32_t cycle, timeMs;

    do
    {
        timeMs = sysTickMillis;
        cycle = SysTick->VAL;
        __ASM volatile("nop");
        __ASM volatile("nop");
    }
    while (timeMs != sysTickMillis);

    if (systick_check_underflow())
    {
        timeMs++;
        cycle = SysTick->VAL;
    }

    return (timeMs * 1000) + (SysTick->LOAD + 1 - cycle) / sysTickPerUs;
}


int GetIdleMax(void)
{
  unsigned int t0 = millis();
	unsigned int lastTime;
	int idleLoops;
	int idleMax;
  while (millis() == t0)
        ;

  lastTime = micros();
  idleLoops = 0;

  __disable_irq();

	while (1)
	{
		unsigned int currentTime;
		unsigned int timePassed;
		idleLoops++;
		currentTime = micros();
		timePassed = currentTime - lastTime;

		if (timePassed >= 500U) //��ȡ500 us ��ѭ������ֵ
		{
				break;
		}
	 }

    __enable_irq();
		
    idleMax = 2 * idleLoops; //  ÿ�����µĿ���������ֵ
    idleLoops = 0;

    return idleMax;
}

