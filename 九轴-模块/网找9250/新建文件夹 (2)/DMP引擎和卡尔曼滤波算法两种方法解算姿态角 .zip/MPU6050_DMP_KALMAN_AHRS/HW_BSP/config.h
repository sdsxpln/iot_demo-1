#ifndef _CONFIG_H
#define _CONFIG_H

#define USE_DMP_WAY 1
#define USE_SOFT_WAY 2

#define USE_WAY USE_DMP_WAY



#endif
