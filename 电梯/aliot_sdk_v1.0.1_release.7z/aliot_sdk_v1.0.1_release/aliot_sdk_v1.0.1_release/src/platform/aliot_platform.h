
#ifndef _PLATFORM_ALIOT_PLATFORM_H_
#define _PLATFORM_ALIOT_PLATFORM_H_

#include "aliot_platform_datatype.h"
#include "os/aliot_platform_os.h"
#include "network/aliot_platform_network.h"
#include "ssl/aliot_platform_ssl.h"


#endif /* _PLATFORM_ALIOT_PLATFORM_H_ */
