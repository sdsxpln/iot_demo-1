//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PosdllDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_POSDLLDEMO_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_PORT_COM                    1000
#define IDC_PORT_LPT                    1001
#define IDC_PORT_USB                    1002
#define IDC_PORT_NET                    1003
#define IDC_PORT_DRV                    1004
#define IDC_OPEN_PORT                   1005
#define IDC_COM_NAME                    1007
#define IDC_BAUDRATE                    1010
#define IDC_SAVE_TO_TXT                 1011
#define IDC_MODE_STANDARD               1012
#define IDC_MODE_PAGE                   1013
#define IDC_PAGE_WIDTH                  1014
#define IDC_QUERY_STATUS                1015
#define IDC_EDIT_STATUS                 1016
#define IDC_PRINT                       1017
#define IDC_CLOSE_PORT                  1018
#define IDC_DATABITS                    1019
#define IDC_STOPBITS                    1020
#define IDC_QUERY_STATUS2               1021
#define IDC_PARITY                      1022
#define IDC_FLOW_CONTROL                1023
#define IDC_LPT_NAME                    1024
#define IDC_IPADDRESS                   1025
#define IDC_DRV_NAME                    1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
